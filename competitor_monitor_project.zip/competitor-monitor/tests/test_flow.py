"""End-to-end verification suite for Competitor Monitor (core.py).

Starts real local HTTP servers (a blog with RSS + pagination + pricing,
a no-blog site, a blocking site, a stub SEO API that rejects keys) and asserts:
- baseline finds all posts,
- a 2nd scan reports 0 new,
- a new post + price change is reported exactly once, and
- each failure mode degrades gracefully.
"""

import json
import os
import sys
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs, urlparse

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import core

STATE = {
    "publish_extra_post": False,
    "pro_price": "$49/mo",
    "seo_reject_key": False,
    "slack_messages": [],
}


class TestServerHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        pass

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length).decode("utf-8", "ignore")

        if self.path == "/slack":
            STATE["slack_messages"].append(json.loads(body))
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"ok")
            return

        if self.path == "/ke-api":
            if STATE["seo_reject_key"]:
                self.send_response(401)
                self.send_header("Content-Type", "application/json")
                self.end_headers()
                self.wfile.write(b'{"error": "Invalid API key"}')
                return
            qs = parse_qs(body)
            kws = qs.get("kw[]", ["workflow automation"])
            data = [
                {"keyword": k, "vol": 3600, "cpc": {"value": "3.25"}, "competition": 0.55}
                for k in kws
            ]
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(json.dumps({"data": data}).encode("utf-8"))
            return

        self.send_response(404)
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)
        mode = self.headers.get("X-Test-Mode", "normal")

        # Mode: bot-blocking site
        if mode == "blocked":
            self.send_response(403)
            self.send_header("Content-Type", "text/html")
            self.end_headers()
            self.wfile.write(b"<html><body>403 Forbidden - Cloudflare Access Denied</body></html>")
            return

        # Mode: site with no blog
        if mode == "noblog":
            if path == "/":
                self._html("<html><body><h1>Brochure Site</h1><p>Welcome.</p></body></html>")
            else:
                self.send_response(404)
                self.end_headers()
            return

        # Mode: normal active competitor blog with RSS + pagination + pricing
        base = f"http://{self.headers.get('Host')}"
        if path == "/":
            self._html(
                f"""<html><head>
                <link rel="alternate" type="application/rss+xml" href="{base}/rss.xml" />
                </head><body>
                <a href="{base}/blog">Blog</a>
                <a href="{base}/pricing">Pricing</a>
                </body></html>"""
            )
            return

        if path == "/rss.xml":
            extra_item = ""
            if STATE["publish_extra_post"]:
                extra_item = f"""
                <item>
                  <title>Autonomous AI Agents in Production</title>
                  <link>{base}/blog/autonomous-ai-agents-production</link>
                  <pubDate>2026-10-24</pubDate>
                  <description>Deploying reliable AI agents with guardrails.</description>
                </item>"""
            rss = f"""<?xml version="1.0" encoding="UTF-8"?>
            <rss version="2.0"><channel><title>Competitor Blog</title>
              {extra_item}
              <item>
                <title>How to Scale Postgres to 10TB</title>
                <link>{base}/blog/scale-postgres-10tb</link>
                <pubDate>2026-10-15</pubDate>
                <description>Partitioning, indexing, and vacuum tuning for large Postgres databases.</description>
              </item>
            </channel></rss>"""
            self.send_response(200)
            self.send_header("Content-Type", "application/rss+xml")
            self.end_headers()
            self.wfile.write(rss.encode("utf-8"))
            return

        if path == "/blog":
            page = query.get("page", ["1"])[0]
            if page == "1":
                self._html(
                    f"""<html><body>
                    <article><a href="{base}/blog/zero-downtime-migrations">Zero Downtime Schema Migrations Guide</a></article>
                    <a href="{base}/blog?page=2" rel="next">Next</a>
                    </body></html>"""
                )
            else:
                self._html(
                    f"""<html><body>
                    <article><a href="{base}/blog/distributed-tracing-opentelemetry">Distributed Tracing with OpenTelemetry</a></article>
                    </body></html>"""
                )
            return

        if path.startswith("/blog/"):
            slug = path.split("/blog/")[-1]
            self._html(
                f"""<html><head>
                <meta property="og:title" content="{slug.replace('-', ' ').title()}" />
                <meta name="description" content="In-depth engineering guide on {slug}." />
                <meta property="article:published_time" content="2026-10-12" />
                </head><body><h1>{slug.replace('-', ' ').title()}</h1></body></html>"""
            )
            return

        if path == "/pricing":
            self._html(
                f"""<html><body>
                <h2>Starter</h2>
                <p>$19/mo</p>
                <h2>Pro Plan</h2>
                <p>{STATE["pro_price"]}</p>
                </body></html>"""
            )
            return

        self.send_response(404)
        self.end_headers()

    def _html(self, body: str):
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(body.encode("utf-8"))


def run_tests():
    srv = HTTPServer(("127.0.0.1", 0), TestServerHandler)
    port = srv.server_port
    threading.Thread(target=srv.serve_forever, daemon=True).start()

    with tempfile.TemporaryDirectory() as tmp:
        os.environ["DATABASE_PATH"] = os.path.join(tmp, "test.db")
        os.environ["ALLOW_PRIVATE_HOSTS"] = "1"
        os.environ["SEO_PROVIDER"] = "keywordseverywhere"
        os.environ["KEYWORDS_EVERYWHERE_API_KEY"] = "test-valid-key"
        os.environ["KE_URL"] = f"http://127.0.0.1:{port}/ke-api"
        os.environ["SLACK_WEBHOOK_URL"] = f"http://127.0.0.1:{port}/slack"
        os.environ["ALERT_ON_BASELINE"] = "1"

        core.init_db()
        cid = core.add_competitor(f"http://localhost:{port}")

        # 1. Baseline Scan (RSS + Paginated Blog + Pricing)
        core.run_scan(cid)
        scans = core.q("SELECT * FROM scans WHERE competitor_id=? ORDER BY id DESC", (cid,))
        assert len(scans) == 1
        assert scans[0]["baseline"] == 1
        assert scans[0]["found_count"] == 3, f"Expected 3 posts (1 RSS + 2 paginated), got {scans[0]}"
        assert scans[0]["new_count"] == 3
        print("[PASS] 1. Baseline scan discovered all 3 posts across RSS + pagination and enriched SEO volume.")

        # 2. Second Scan on unchanged domain -> 0 new posts
        prev_slack_count = len(STATE["slack_messages"])
        core.run_scan(cid)
        scan2 = core.q("SELECT * FROM scans WHERE competitor_id=? ORDER BY id DESC LIMIT 1", (cid,))[0]
        assert scan2["baseline"] == 0
        assert scan2["new_count"] == 0, f"Expected 0 new posts on 2nd scan, got {scan2}"
        assert len(STATE["slack_messages"]) == prev_slack_count, "No alert should fire when nothing changed"
        print("[PASS] 2. Second scan reported 0 new posts and suppressed duplicate Slack alert.")

        # 3. New post published + Pro price changed ($49/mo -> $59/mo)
        STATE["publish_extra_post"] = True
        STATE["pro_price"] = "$59/mo"
        core.run_scan(cid)
        scan3 = core.q("SELECT * FROM scans WHERE competitor_id=? ORDER BY id DESC LIMIT 1", (cid,))[0]
        assert scan3["new_count"] == 1
        assert scan3["price_changes"] == 1
        assert len(STATE["slack_messages"]) == prev_slack_count + 1
        latest_msg = STATE["slack_messages"][-1]["text"]
        assert "Autonomous AI Agents in Production" in latest_msg
        assert "$59/mo" in latest_msg
        print("[PASS] 3. Third scan detected exactly 1 new post + 1 pricing change and sent Slack alert.")

        # 4. Edge Case: Site with no blog
        core.S.headers["X-Test-Mode"] = "noblog"
        os.environ["DATABASE_PATH"] = os.path.join(tmp, "noblog.db")
        core.init_db()
        cid_nb = core.add_competitor(f"http://localhost:{port}")
        core.run_scan(cid_nb)
        scan_nb = core.q("SELECT * FROM scans WHERE competitor_id=?", (cid_nb,))[0]
        assert "No blog or articles detected" in scan_nb["summary"]
        print(f"[PASS] 4. No-blog site handled gracefully: '{scan_nb['summary']}'")

        # 5. Edge Case: Bot-blocking site (HTTP 403)
        core.S.headers["X-Test-Mode"] = "blocked"
        os.environ["DATABASE_PATH"] = os.path.join(tmp, "blocked.db")
        core.init_db()
        cid_bl = core.add_competitor(f"http://localhost:{port}")
        core.run_scan(cid_bl)
        scan_bl = core.q("SELECT * FROM scans WHERE competitor_id=?", (cid_bl,))[0]
        errs_bl = core.q("SELECT * FROM errors WHERE competitor_id=?", (cid_bl,))
        assert scan_bl["status"] == "failed"
        assert any("Blocked by site (HTTP 403)" in e["message"] for e in errs_bl)
        print("[PASS] 5. Bot-blocking site (HTTP 403) logged clear error and stopped hammering after 3 blocks.")

        # 6. Edge Case: Invalid SEO API Key (HTTP 401)
        core.S.headers["X-Test-Mode"] = "normal"
        STATE["seo_reject_key"] = True
        os.environ["DATABASE_PATH"] = os.path.join(tmp, "badkey.db")
        core.init_db()
        cid_bk = core.add_competitor(f"http://localhost:{port}")
        core.run_scan(cid_bk)
        errs_bk = core.q("SELECT * FROM errors WHERE competitor_id=? AND stage='seo'", (cid_bk,))
        arts_bk = core.q("SELECT * FROM articles WHERE competitor_id=?", (cid_bk,))
        assert len(arts_bk) == 4
        assert any("invalid_key" in e["message"] for e in errs_bk)
        assert all(a["seo_status"] == "pending" for a in arts_bk)
        print("[PASS] 6. Invalid SEO API key logged [invalid_key] error without failing scan; articles kept pending.")

    srv.shutdown()
    print("\nALL 6 END-TO-END FLOW TESTS PASSED!")


if __name__ == "__main__":
    run_tests()
