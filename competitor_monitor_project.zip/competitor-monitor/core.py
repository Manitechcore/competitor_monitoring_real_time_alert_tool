"""Competitor monitor core: storage, scraping, change detection, SEO enrichment, alerts."""
import gzip, ipaddress, json, logging, os, re, smtplib, socket, sqlite3
from datetime import datetime, timezone
from email.message import EmailMessage
from urllib.parse import parse_qsl, urlencode, urljoin, urlparse, urlunparse

import requests
from bs4 import BeautifulSoup
from dateutil import parser as dparse

log = logging.getLogger("monitor")
env = lambda k, d="": os.getenv(k, d).strip()
now = lambda: datetime.now(timezone.utc).isoformat(timespec="seconds")

# ───────────────────────── storage ─────────────────────────
SCHEMA = """
CREATE TABLE IF NOT EXISTS competitors(id INTEGER PRIMARY KEY, domain TEXT UNIQUE, base_url TEXT,
  created_at TEXT, last_scan_at TEXT, last_scan_id INTEGER, last_status TEXT);
CREATE TABLE IF NOT EXISTS articles(id INTEGER PRIMARY KEY, competitor_id INTEGER, key TEXT, url TEXT,
  title TEXT, description TEXT, published_at TEXT, source TEXT, first_seen_at TEXT, scan_id INTEGER,
  detail INTEGER DEFAULT 0, keyword TEXT, volume INTEGER, cpc REAL, competition REAL,
  seo_status TEXT DEFAULT 'pending', UNIQUE(competitor_id,key));
CREATE TABLE IF NOT EXISTS scans(id INTEGER PRIMARY KEY, competitor_id INTEGER, started_at TEXT, finished_at TEXT,
  status TEXT, baseline INTEGER DEFAULT 0, found_count INTEGER DEFAULT 0, new_count INTEGER DEFAULT 0,
  price_changes INTEGER DEFAULT 0, alert_status TEXT, summary TEXT);
CREATE TABLE IF NOT EXISTS errors(id INTEGER PRIMARY KEY, scan_id INTEGER, competitor_id INTEGER, at TEXT, stage TEXT, message TEXT);
CREATE TABLE IF NOT EXISTS price_snapshots(id INTEGER PRIMARY KEY, competitor_id INTEGER, scan_id INTEGER, url TEXT, prices TEXT, at TEXT);
CREATE TABLE IF NOT EXISTS price_changes(id INTEGER PRIMARY KEY, competitor_id INTEGER, scan_id INTEGER, url TEXT, added TEXT, removed TEXT, at TEXT);
"""

def conn():
    p = env("DATABASE_PATH", "data/monitor.db")
    os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
    c = sqlite3.connect(p, timeout=30); c.row_factory = sqlite3.Row
    return c

def q(sql, a=()):
    c = conn()
    try: return [dict(r) for r in c.execute(sql, a).fetchall()]
    finally: c.close()

def ex(sql, a=()):
    c = conn()
    try:
        cur = c.execute(sql, a); c.commit(); return cur.lastrowid
    finally: c.close()

def init_db():
    c = conn(); c.execute("PRAGMA journal_mode=WAL"); c.executescript(SCHEMA)
    c.execute("UPDATE scans SET status='failed', summary='Interrupted by restart' WHERE status='running'")
    c.commit(); c.close()

# ───────────────────────── fetching ─────────────────────────
class FetchError(Exception):
    def __init__(s, kind, msg): super().__init__(msg); s.kind = kind

S = requests.Session()
S.headers.update({
    "User-Agent": env("USER_AGENT", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36"),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Cache-Control": "no-cache",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Upgrade-Insecure-Requests": "1",
})

def check_host(url):
    """Block private/loopback targets (SSRF guard) unless ALLOW_PRIVATE_HOSTS=1."""
    host = urlparse(url).hostname
    if not host: raise FetchError("invalid", "Invalid URL")
    try: infos = socket.getaddrinfo(host, None)
    except socket.gaierror: raise FetchError("dns", f"Cannot resolve {host}")
    if env("ALLOW_PRIVATE_HOSTS") == "1": return
    for i in infos:
        ip = ipaddress.ip_address(i[4][0])
        if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved:
            raise FetchError("forbidden", "Private/internal addresses are not allowed")

def _render(url):
    from playwright.sync_api import sync_playwright  # optional dependency
    with sync_playwright() as p:
        b = p.chromium.launch(); pg = b.new_page(user_agent=S.headers["User-Agent"])
        pg.goto(url, wait_until="networkidle", timeout=30000); html = pg.content(); b.close()
    return html

def fetch(url, render=False):
    check_host(url)
    if render and env("USE_PLAYWRIGHT") == "1": return _render(url)
    err = None
    for _ in range(2):
        try: r = S.get(url, timeout=int(env("REQUEST_TIMEOUT", "15")))
        except requests.Timeout: err = FetchError("timeout", f"Timed out: {url}"); continue
        except requests.RequestException as e: err = FetchError("network", f"{type(e).__name__} fetching {url}"); continue
        c = r.status_code
        if c in (401, 403, 429) or (c == 503 and "cloudflare" in r.text[:3000].lower()):
            err = FetchError("blocked", f"Blocked by site (HTTP {c}): {url}"); break
        if c in (404, 410): raise FetchError("not_found", f"HTTP {c}: {url}")
        if c >= 500: err = FetchError("server", f"HTTP {c}: {url}"); continue
        if c >= 400: raise FetchError("http", f"HTTP {c}: {url}")
        if url.endswith(".gz"): return gzip.decompress(r.content).decode("utf-8", "ignore")
        if "charset" not in r.headers.get("content-type", "").lower(): r.encoding = "utf-8"
        return r.text
    if err.kind == "blocked" and env("USE_PLAYWRIGHT") == "1":
        try: return _render(url)
        except Exception as e: raise FetchError("blocked", f"{err} (browser fallback failed: {e})")
    raise err

# ───────────────────────── URL helpers ─────────────────────────
TRACK = ("utm_", "fbclid", "gclid", "mc_", "ref")
BLOGW = {"blog", "blogs", "resources", "resource", "articles", "article", "news", "insights", "posts",
         "learn", "guides", "stories", "library", "journal", "updates", "changelog", "engineering",
         "opinion", "business", "sci-tech", "technology", "sport", "entertainment", "world", "national",
         "perspectives", "announcements", "press"}
SKIP = {"tag", "tags", "category", "categories", "author", "authors", "page", "topic", "topics", "feed",
        "search", "wp-content", "wp-json", "cdn-cgi", "login", "signup", "register", "account",
        "privacy", "privacy-policy", "terms", "terms-of-service", "terms-and-conditions", "cookie-policy",
        "contact", "contact-us", "about", "about-us", "careers", "pricing", "subscription", "blog-scanner"}
EXT = re.compile(r"\.(jpe?g|png|gif|svg|webp|pdf|zip|css|js|xml|mp4|ico)$", re.I)

def normalize_domain(raw):
    raw = (raw or "").strip()
    if not raw: raise ValueError("Enter a domain")
    p = urlparse(raw if "//" in raw else "//" + raw, scheme="https")
    host = (p.netloc or "").lower()
    if not host or not re.match(r"^[a-z0-9.\-:\[\]]+$", host) or ("." not in host and "localhost" not in host):
        raise ValueError(f"'{raw}' is not a valid domain")
    return host.removeprefix("www."), f"{p.scheme}://{host}"

def host_key(u): return urlparse(u).netloc.lower().removeprefix("www.")
def segs(u): return [s for s in urlparse(u).path.split("/") if s]

def clean(u):
    p = urlparse(u)
    qs = [(k, v) for k, v in parse_qsl(p.query) if not k.lower().startswith(TRACK)]
    return urlunparse((p.scheme, p.netloc.lower(), re.sub(r"/+$", "", p.path) or "/", "", urlencode(qs), ""))

def ukey(u):
    p = urlparse(clean(u)); return host_key(u) + p.path + ("?" + p.query if p.query else "")

def looks_like_post(u, base):
    path = urlparse(u).path
    if host_key(u) != host_key(base) or EXT.search(path): return False
    s = [x.lower() for x in segs(u)]
    if not s or any(x in SKIP for x in s): return False
    last = s[-1]
    has_slug = bool(re.search(r"(article\d+\.ece$|\.cms$|[a-z0-9]+-[a-z0-9]+-[a-z0-9]+)", last))
    if len(s) == 1:
        return has_slug and len(last) >= 16
    return (
        s[0] in BLOGW
        or (len(s) >= 3 and s[1] in BLOGW)
        or bool(re.search(r"/20\d\d/\d\d/", path))
        or has_slug
    )

def is_listing(u):
    s = segs(u); return 0 < len(s) <= 2 and s[-1].lower() in BLOGW

def pdate(v):
    if not v: return None
    try: d = dparse.parse(str(v).strip())
    except (ValueError, OverflowError): return None
    return d.date().isoformat() if 1995 < d.year < 2100 else None

def _find_key(o, k):
    if isinstance(o, dict):
        if k in o and isinstance(o[k], str): return o[k]
        o = list(o.values())
    if isinstance(o, list):
        for v in o:
            r = _find_key(v, k)
            if r: return r

def extract_meta(html):
    s = BeautifulSoup(html, "lxml")
    def m(*names):
        for n in names:
            t = s.find("meta", attrs={"property": n}) or s.find("meta", attrs={"name": n})
            if t and t.get("content", "").strip(): return t["content"].strip()
    title = m("og:title", "twitter:title") or (s.h1.get_text(" ", strip=True) if s.h1 else None) \
        or (s.title.get_text(strip=True) if s.title else None)
    date = m("article:published_time", "datePublished", "date", "pubdate", "publish_date")
    if not date:
        for t in s.find_all("script", type="application/ld+json"):
            try: date = _find_key(json.loads(t.string or ""), "datePublished")
            except ValueError: continue
            if date: break
    if not date:
        t = s.find("time", attrs={"datetime": True}); date = t["datetime"] if t else None
    return {"title": title, "desc": m("description", "og:description", "twitter:description"), "date": pdate(date)}

# ───────────────────────── discovery ─────────────────────────
def discover(base, err):
    """Return (candidates, homepage_html). Sources: homepage, RSS/Atom, sitemaps, listing pages + pagination."""
    cands = {}
    def add(u, title=None, date=None, desc=None, src=""):
        u = clean(u); d = cands.setdefault(ukey(u), {"url": u, "key": ukey(u), "title": None, "date": None, "desc": None, "source": src})
        for f, v in (("title", title), ("date", date), ("desc", desc)):
            if v and not d[f]: d[f] = v
    blocked = [0]
    def safe(url, stage, render=False):
        if blocked[0] >= 3: return None            # site is blocking us: stop hammering it
        try: return fetch(url, render)
        except FetchError as e:
            if e.kind == "blocked":
                blocked[0] += 1
                if blocked[0] == 1: err(stage, str(e) + " — further requests will be skipped if blocking continues")
                if blocked[0] == 3: err(stage, "Site keeps blocking requests; stopped crawling. Try USE_PLAYWRIGHT=1 or a different USER_AGENT")
            elif e.kind != "not_found": err(stage, str(e))
            return None

    home = safe(base + "/", "homepage"); hs = BeautifulSoup(home, "lxml") if home else None
    feeds, listings = [], []
    if hs:
        for l in hs.find_all("link", href=True):
            if "alternate" in (l.get("rel") or []) and "xml" in (l.get("type") or ""): feeds.append(urljoin(base + "/", l["href"]))
        for a in hs.find_all("a", href=True):
            h = urljoin(base + "/", a["href"]).split("#")[0]
            if host_key(h) == host_key(base) and is_listing(h): listings.append(clean(h))
        for h, t in _post_links(hs, base + "/", base).items(): add(h, t, src="homepage")

    # RSS / Atom
    ok = 0
    for f in dict.fromkeys(feeds + [base + p for p in ("/feed", "/rss.xml", "/feed.xml", "/feeder/default.rss", "/blog/feed", "/blog/rss.xml", "/atom.xml", "/index.xml")]):
        if ok >= 2: break
        txt = safe(f, "rss")
        if not txt or not re.search(r"<(rss|feed|rdf)", txt[:2000], re.I): continue
        ok += 1
        x = BeautifulSoup(txt, "xml")
        for it in x.find_all(["item", "entry"]):
            ln = it.find("link"); link = (ln.get("href") or ln.get_text(strip=True)) if ln else None
            if not link: continue
            dt = next((it.find(n) for n in ("pubDate", "published", "updated", "date") if it.find(n)), None)
            ds = it.find("description") or it.find("summary")
            desc = BeautifulSoup(ds.get_text(), "lxml").get_text(" ", strip=True)[:300] if ds else None
            add(urljoin(base + "/", link), it.find("title").get_text(strip=True) if it.find("title") else None,
                pdate(dt.get_text()) if dt else None, desc, "rss")

    # sitemaps (robots.txt + common locations)
    sms = []
    rb = safe(base + "/robots.txt", "robots")
    if rb: sms += re.findall(r"(?im)^sitemap:\s*(\S+)", rb)
    sms += [base + p for p in ("/sitemap.xml", "/sitemap_index.xml", "/wp-sitemap.xml")]
    seen, budget = set(), [15]
    def walk(u, depth=0):
        if u in seen or budget[0] <= 0: return
        seen.add(u); budget[0] -= 1
        txt = safe(u, "sitemap")
        if not txt: return
        locs = [l.get_text(strip=True) for l in BeautifulSoup(txt, "xml").find_all("loc")]
        if "<sitemapindex" in txt[:3000] and depth < 2:
            for l in sorted(locs, key=lambda x: not re.search(r"post|blog|article|news", x, re.I)): walk(l, depth + 1)
        else:
            xml_soup = BeautifulSoup(txt, "xml")
            url_tags = xml_soup.find_all("url")
            if url_tags:
                for u_tag in url_tags[:5000]:
                    loc_tag = u_tag.find("loc")
                    if not loc_tag: continue
                    l = loc_tag.get_text(strip=True)
                    if looks_like_post(l, base):
                        lm = u_tag.find("lastmod")
                        add(l, date=pdate(lm.get_text()) if lm else None, src="sitemap")
            else:
                for l in locs[:5000]:
                    if looks_like_post(l, base): add(l, src="sitemap")
    for u in dict.fromkeys(sms): walk(u)

    # WordPress REST API (/wp-json/wp/v2/posts) — bypasses HTML scraping & WAF rules on WP blogs
    wp_txt = safe(base + "/wp-json/wp/v2/posts?per_page=30", "wp_api")
    if wp_txt and wp_txt.lstrip().startswith("["):
        try:
            for wp_post in json.loads(wp_txt):
                if not isinstance(wp_post, dict): continue
                wp_link = wp_post.get("link")
                if not wp_link: continue
                wp_title = BeautifulSoup((wp_post.get("title") or {}).get("rendered", ""), "lxml").get_text(" ", strip=True)
                wp_desc = BeautifulSoup((wp_post.get("excerpt") or {}).get("rendered", ""), "lxml").get_text(" ", strip=True)[:300]
                wp_date = pdate(wp_post.get("date") or wp_post.get("modified"))
                add(wp_link, wp_title, wp_date, wp_desc, "wp-json")
        except Exception:
            pass

    # listing pages with pagination
    for lp in list(dict.fromkeys(listings + [base + p for p in ("/blog", "/resources", "/articles", "/news", "/insights")]))[:6]:
        queue, visited, n = [lp], set(), 0
        while queue and n < int(env("MAX_PAGES", "5")):
            u = queue.pop(0)
            if u in visited: continue
            visited.add(u); h = safe(u, "listing")
            if not h: continue
            n += 1; s = BeautifulSoup(h, "lxml")
            for pu, t in _post_links(s, u, base).items(): add(pu, t, src="listing")
            queue += [x for x in _next_links(s, u) if x not in visited]
    return list(cands.values()), home

def _post_links(s, url, base):
    out = {}
    for a in s.find_all("a", href=True):
        h = urljoin(url, a["href"]).split("#")[0]
        if not h.startswith("http") or host_key(h) != host_key(base) or is_listing(h): continue
        in_art = a.find_parent(["article", "h1", "h2", "h3", "h4"]) is not None
        if looks_like_post(h, base) or (in_art and len(segs(h)) >= 2 and not EXT.search(h) and not any(x in SKIP for x in segs(h))):
            t = a.get_text(" ", strip=True); out.setdefault(clean(h), t if len(t) > 8 else None)
    return out

def _next_links(s, url):
    out, path = [], urlparse(url).path.rstrip("/")
    ln = s.find("link", rel="next")
    if ln and ln.get("href"): out.append(clean(urljoin(url, ln["href"])) if "?" not in ln["href"] else urljoin(url, ln["href"]))
    for a in s.find_all("a", href=True):
        h = urljoin(url, a["href"]); t = a.get_text(" ", strip=True).lower()
        if "next" in (a.get("rel") or []) or t in ("next", "next page", "older", "older posts", "›", "»", "next →"): out.append(h)
        elif urlparse(h).path.rstrip("/").startswith(path) and re.search(r"([?&]page=\d+|/page/\d+)", h): out.append(h)
    return list(dict.fromkeys(out))

# ───────────────────────── pricing ─────────────────────────
PRICE = re.compile(r"(?:US\$|\$|€|£|₹)\s?\d[\d,]*(?:\.\d{1,2})?(?:\s?/\s?[A-Za-z]+)?")

def extract_prices(html):
    s = BeautifulSoup(html, "lxml")
    for t in s(["script", "style", "noscript", "svg"]): t.decompose()
    out, label = [], ""
    for line in (l.strip() for l in s.get_text("\n").split("\n")):
        if not line: continue
        ms = PRICE.findall(line)
        if ms and len(line) < 120: out += [f"{label[:40]} {m}".strip() for m in ms]
        elif len(line) < 40: label = line
    return sorted(set(out))[:60]

def track_pricing(c, sid, home_html, err):
    base, urls = c["base_url"], [c["base_url"] + "/pricing"]
    if home_html:
        for a in BeautifulSoup(home_html, "lxml").find_all("a", href=True):
            h = urljoin(base + "/", a["href"]).split("#")[0]
            if host_key(h) == host_key(base) and re.search(r"pric|plans", urlparse(h).path, re.I): urls.append(clean(h))
    changes, pages = [], 0
    for u in list(dict.fromkeys(urls))[:3]:
        try: html = fetch(u)
        except FetchError as e:
            if e.kind != "not_found": err("pricing", str(e))
            continue
        prices = extract_prices(html)
        if not prices and env("USE_PLAYWRIGHT") == "1":
            try: prices = extract_prices(fetch(u, render=True))
            except Exception as e: err("pricing", f"Browser render failed for {u}: {e}")
        pages += 1
        prev = q("SELECT prices FROM price_snapshots WHERE competitor_id=? AND url=? ORDER BY id DESC LIMIT 1", (c["id"], u))
        ex("INSERT INTO price_snapshots(competitor_id,scan_id,url,prices,at) VALUES(?,?,?,?,?)", (c["id"], sid, u, json.dumps(prices), now()))
        if prev:
            old = json.loads(prev[0]["prices"]); add_, rem = sorted(set(prices) - set(old)), sorted(set(old) - set(prices))
            if add_ or rem:
                ex("INSERT INTO price_changes(competitor_id,scan_id,url,added,removed,at) VALUES(?,?,?,?,?,?)",
                   (c["id"], sid, u, json.dumps(add_), json.dumps(rem), now()))
                changes.append({"url": u, "added": add_, "removed": rem})
    return changes, pages

# ───────────────────────── SEO enrichment ─────────────────────────
class SeoError(Exception):
    def __init__(s, kind, msg): super().__init__(msg); s.kind = kind

LEAD = {"how", "to", "what", "is", "are", "why", "the", "a", "an", "best", "top", "ultimate", "complete", "guide", "your", "you"}
STOP = LEAD | {"and", "or", "of", "in", "on", "for", "with", "by", "from", "at", "as", "this", "that", "it", "our", "we", "vs"}

def keyword_candidates(r):
    out = []
    t = re.split(r"\s[|–—•-]\s", r.get("title") or "")[0].split(":")[0]
    w = re.findall(r"[a-z0-9']+", t.lower())
    while w and (w[0] in LEAD or w[0].isdigit()): w.pop(0)
    if len(w) >= 2: out.append(" ".join(w[:6]))
    sl = [x for x in re.split(r"[-_]", (segs(r["url"]) or [""])[-1].lower()) if x.isalpha() and x not in STOP][:5]
    if len(sl) >= 2: out.append(" ".join(sl))
    return list(dict.fromkeys(out))[:3]

def lookup(kws):
    p = env("SEO_PROVIDER").lower()
    if p == "dataforseo": return _dfs(kws)
    if p in ("keywordseverywhere", "keywords_everywhere", "ke"): return _ke(kws)
    raise SeoError("config", f"Unknown SEO_PROVIDER '{p}' (use dataforseo or keywordseverywhere)")

def _post(url, **kw):
    try: return requests.post(url, timeout=30, **kw)
    except requests.RequestException as e: raise SeoError("network", f"SEO API unreachable: {type(e).__name__}")

def _dfs(kws):
    u, pw = env("DATAFORSEO_LOGIN"), env("DATAFORSEO_PASSWORD")
    if not (u and pw): raise SeoError("invalid_key", "DataForSEO credentials missing")
    r = _post(env("DFS_URL", "https://api.dataforseo.com/v3/keywords_data/google_ads/search_volume/live"), auth=(u, pw),
              json=[{"keywords": kws, "location_code": int(env("SEO_LOCATION_CODE", "2840")), "language_code": env("SEO_LANGUAGE", "en")}])
    if r.status_code in (401, 403): raise SeoError("invalid_key", f"DataForSEO rejected the credentials (HTTP {r.status_code})")
    if r.status_code == 429: raise SeoError("rate_limit", "DataForSEO rate limit hit")
    try: j = r.json()
    except ValueError: raise SeoError("network", f"DataForSEO returned non-JSON (HTTP {r.status_code})")
    if str(j.get("status_code", "")).startswith("401"): raise SeoError("invalid_key", "DataForSEO rejected the credentials")
    out = {}
    for t in j.get("tasks") or []:
        if str(t.get("status_code", "")).startswith("401"): raise SeoError("invalid_key", "DataForSEO rejected the credentials")
        if t.get("status_code") != 20000: raise SeoError("api", f"DataForSEO: {t.get('status_message')}")
        for it in t.get("result") or []:
            out[it["keyword"]] = {"volume": it.get("search_volume"), "cpc": it.get("cpc"), "competition": it.get("competition")}
    return out

def _ke(kws):
    k = env("KEYWORDS_EVERYWHERE_API_KEY")
    if not k: raise SeoError("invalid_key", "Keywords Everywhere API key missing")
    r = _post(env("KE_URL", "https://api.keywordseverywhere.com/v1/get_keyword_data"),
              headers={"Authorization": "Bearer " + k, "Accept": "application/json"},
              data={"country": env("SEO_COUNTRY", "us"), "currency": "USD", "dataSource": "gkp", "kw[]": kws})
    if r.status_code in (401, 403): raise SeoError("invalid_key", f"Keywords Everywhere rejected the API key (HTTP {r.status_code})")
    if r.status_code == 402: raise SeoError("quota", "Keywords Everywhere credits exhausted")
    if r.status_code == 429: raise SeoError("rate_limit", "Keywords Everywhere rate limit hit")
    try: data = r.json().get("data") or []
    except ValueError: raise SeoError("network", f"Keywords Everywhere returned non-JSON (HTTP {r.status_code})")
    def num(v):
        try: return float((v or {}).get("value") if isinstance(v, dict) else v)
        except (TypeError, ValueError): return None
    return {it["keyword"]: {"volume": it.get("vol"), "cpc": num(it.get("cpc")), "competition": num(it.get("competition"))} for it in data}

def enrich(cid, err):
    rows = q("SELECT * FROM articles WHERE competitor_id=? AND seo_status IN ('pending','no_api') "
             "ORDER BY published_at DESC, id DESC LIMIT ?", (cid, int(env("ENRICH_LIMIT", "10"))))
    dead = None
    for r in rows:
        kws = keyword_candidates(r)
        if not kws: ex("UPDATE articles SET seo_status='no_data' WHERE id=?", (r["id"],)); continue
        data, status = {}, "done"
        if not env("SEO_PROVIDER"): status = "no_api"
        elif dead: status = "pending"
        else:
            try: data = lookup(kws)
            except SeoError as e:
                dead = e; status = "pending"; err("seo", f"[{e.kind}] {e}")
        if status == "done" and not data: status = "no_data"
        kw, m = max(data.items(), key=lambda kv: kv[1].get("volume") or -1) if data else (kws[0], {})
        ex("UPDATE articles SET keyword=?,volume=?,cpc=?,competition=?,seo_status=? WHERE id=?",
           (kw, m.get("volume"), m.get("cpc"), m.get("competition"), status, r["id"]))

# ───────────────────────── alerts ─────────────────────────
def build_message(c, new, changes, baseline, total):
    L = []
    if baseline: L.append(f"📊 Now monitoring {c['domain']} — {total} articles indexed (baseline). Latest:")
    elif new: L.append(f"🚨 {c['domain']} published {len(new)} new post{'s' if len(new) != 1 else ''} since the last scan")
    for i, a in enumerate(new[:15], 1):
        kw = f"keyword: {a['keyword']} · {a['volume']:,}/mo" if a.get("volume") is not None else (f"keyword: {a['keyword']} · volume n/a" if a.get("keyword") else "keyword: n/a")
        L.append(f"{i}. {a['title']} — {a['url']}\n    {a.get('published_at') or 'date unknown'} · {kw}")
    if len(new) > 15: L.append(f"…and {len(new) - 15} more")
    for ch in changes:
        L.append(f"💰 Pricing changed on {ch['url']}")
        L += [f"    + {x}" for x in ch["added"][:8]] + [f"    − {x}" for x in ch["removed"][:8]]
    return "\n".join(L)

def send_alert(msg, subject, err):
    res = []
    if env("SLACK_WEBHOOK_URL"):
        try:
            r = requests.post(env("SLACK_WEBHOOK_URL"), json={"text": msg}, timeout=10)
            if r.status_code == 200: res.append("slack:sent")
            else: res.append("slack:failed"); err("alert", f"Slack webhook rejected the message (HTTP {r.status_code}: {r.text[:80]})")
        except requests.RequestException as e: res.append("slack:failed"); err("alert", f"Slack webhook unreachable: {type(e).__name__}")
    if env("SMTP_HOST") and env("ALERT_EMAIL_TO"):
        try:
            m = EmailMessage(); m["Subject"], m["To"] = subject, env("ALERT_EMAIL_TO")
            m["From"] = env("ALERT_EMAIL_FROM") or env("SMTP_USER"); m.set_content(msg)
            with smtplib.SMTP(env("SMTP_HOST"), int(env("SMTP_PORT", "587")), timeout=15) as s:
                s.starttls()
                if env("SMTP_USER"): s.login(env("SMTP_USER"), env("SMTP_PASSWORD"))
                s.send_message(m)
            res.append("email:sent")
        except (smtplib.SMTPException, OSError) as e: res.append("email:failed"); err("alert", f"Email failed: {e}")
    return ", ".join(res) or "not_configured"

# ───────────────────────── orchestration ─────────────────────────
def add_competitor(raw):
    domain, base = normalize_domain(raw)
    try: check_host(base)
    except FetchError as e: raise ValueError(str(e))
    if q("SELECT 1 FROM competitors WHERE domain=?", (domain,)): raise ValueError(f"{domain} is already being monitored")
    return ex("INSERT INTO competitors(domain,base_url,created_at) VALUES(?,?,?)", (domain, base, now()))

def run_scan(cid):
    c = q("SELECT * FROM competitors WHERE id=?", (cid,))[0]
    sid = ex("INSERT INTO scans(competitor_id,started_at,status) VALUES(?,?,'running')", (cid, now()))
    nerr = [0]
    def err(stage, m):
        nerr[0] += 1; log.warning("[%s] %s: %s", c["domain"], stage, m)
        ex("INSERT INTO errors(scan_id,competitor_id,at,stage,message) VALUES(?,?,?,?,?)", (sid, cid, now(), stage, m[:500]))
    status, summary, alert, baseline, found, new, changes = "completed", "", "none", False, [], [], []
    try:
        known = {r["key"] for r in q("SELECT key FROM articles WHERE competitor_id=?", (cid,))}
        baseline = not q("SELECT 1 FROM scans WHERE competitor_id=? AND status LIKE 'completed%' LIMIT 1", (cid,))
        found, home = discover(c["base_url"], err)
        for f in found:
            if f["key"] in known: continue          # dedupe: already stored → not new
            title = f["title"] or (segs(f["url"]) or ["untitled"])[-1].replace("-", " ").replace("_", " ").title()
            ex("INSERT OR IGNORE INTO articles(competitor_id,key,url,title,description,published_at,source,first_seen_at,scan_id,detail) "
               "VALUES(?,?,?,?,?,?,?,?,?,?)", (cid, f["key"], f["url"], title, f["desc"], f["date"], f["source"], now(), sid,
                                              1 if f["title"] and f["desc"] and f["date"] else 0))
        # fetch article pages for missing title/date/description (new items first, then backfill)
        fails = 0
        for a in q("SELECT * FROM articles WHERE competitor_id=? AND detail=0 ORDER BY id DESC LIMIT ?", (cid, int(env("MAX_DETAIL_FETCHES", "40")))):
            try: m = extract_meta(fetch(a["url"]))
            except FetchError as e:
                if e.kind == "not_found": ex("UPDATE articles SET detail=2 WHERE id=?", (a["id"],))
                fails += 1
                if fails <= 3: err("article", str(e))
                continue
            ex("UPDATE articles SET title=?,description=COALESCE(description,?),published_at=COALESCE(published_at,?),detail=1 WHERE id=?",
               (m["title"] if a["source"] != "rss" and m["title"] else a["title"], m["desc"], m["date"], a["id"]))
        if fails > 3: err("article", f"...and {fails - 3} more article pages failed")
        enrich(cid, err)
        changes, pages = track_pricing(c, sid, home, err)
        new = q("SELECT * FROM articles WHERE scan_id=? ORDER BY published_at DESC, id", (sid,))
        total = q("SELECT COUNT(*) n FROM articles WHERE competitor_id=?", (cid,))[0]["n"]
        if not found and not total: summary = "No blog or articles detected on this site"
        else: summary = f"{len(found)} articles discovered, {len(new)} new" + (" (baseline scan)" if baseline else "")
        if not pages: summary += "; no pricing page found"
        if (new and (not baseline or env("ALERT_ON_BASELINE", "1") == "1")) or changes:
            alert = send_alert(build_message(c, new if not baseline else new[:5], changes, baseline, total),
                               f"{c['domain']}: {len(new)} new post(s)" if new else f"{c['domain']}: pricing changed", err)
        if not found and not total and not home and nerr[0]: status = "failed"
        elif nerr[0]: status = "completed_with_errors"
    except Exception as e:  # never let a scan crash silently
        log.exception("scan crashed"); err("internal", f"{type(e).__name__}: {e}"); status, summary = "failed", "Unexpected error"
    ex("UPDATE scans SET finished_at=?,status=?,baseline=?,found_count=?,new_count=?,price_changes=?,alert_status=?,summary=? WHERE id=?",
       (now(), status, int(baseline), len(found), len(new), len(changes), alert, summary, sid))
    ex("UPDATE competitors SET last_scan_at=?,last_scan_id=?,last_status=? WHERE id=?", (now(), sid, status, cid))
    return sid


def compute_weekly_cadence(articles):
    dates = sorted([a["published_at"] for a in articles if a.get("published_at")], reverse=True)
    if not dates:
        return {"posts_per_week": round(len(articles) / 4.0, 1) if articles else 0.0, "latest_date": None, "dated_count": 0}
    try:
        newest = dparse.parse(dates[0]).date()
        oldest = dparse.parse(dates[-1]).date()
        span_weeks = max(1.0, (newest - oldest).days / 7.0)
        rate = round(len(dates) / span_weeks, 1)
    except Exception:
        rate = round(len(dates) / 4.0, 1)
    return {"posts_per_week": rate, "latest_date": dates[0], "dated_count": len(dates)}

def compare_competitors(cids):
    out = []
    for cid in cids:
        comps = q("SELECT * FROM competitors WHERE id=?", (cid,))
        if not comps: continue
        c = comps[0]
        arts = q("SELECT * FROM articles WHERE competitor_id=? ORDER BY published_at DESC, id DESC", (cid,))
        scans = q("SELECT * FROM scans WHERE competitor_id=? ORDER BY id DESC LIMIT 1", (cid,))
        snaps = q("SELECT * FROM price_snapshots WHERE competitor_id=? ORDER BY id DESC LIMIT 1", (cid,))
        cadence = compute_weekly_cadence(arts)
        prices = json.loads(snaps[0]["prices"]) if snaps else []
        out.append({
            "competitor": c,
            "scan": scans[0] if scans else None,
            "total_articles": len(arts),
            "new_articles": scans[0]["new_count"] if scans else 0,
            "posts_per_week": cadence["posts_per_week"],
            "latest_date": cadence["latest_date"],
            "pricing_url": snaps[0]["url"] if snaps else None,
            "prices": prices,
            "top_keywords": [a["keyword"] for a in arts[:5] if a.get("keyword")],
        })
    return out
