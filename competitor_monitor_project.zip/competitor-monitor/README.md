# Competitor Monitor

Enter a competitor's domain → the tool scrapes its blog, remembers what it has seen, and alerts you (Slack/email) **only about what's new**, with target keyword + search volume for each post. It also snapshots pricing pages and flags price changes.

**Own scraper, no scraping API.** `requests` + `BeautifulSoup` (+ optional Playwright). SQLite for persistence.

## How it works
| Step | Implementation (`core.py`) |
|---|---|
| Discover posts | Homepage links → RSS/Atom (declared + common paths) → `robots.txt`/`sitemap.xml` (indexes, `.gz`) → blog listing pages incl. `rel=next`, `?page=N`, `/page/N` |
| Extract | Title (og:title/h1/title), date (meta, JSON-LD `datePublished`, `<time>`, RSS), meta description. Missing dates are stored as `NULL` and shown as "—" |
| Dedupe | URLs canonicalised (tracking params, fragments, trailing slash, `www.`, scheme) → unique `(competitor, key)` |
| Change detection | A post is "new" only if its key isn't already in the DB. First scan = baseline (`baseline=1`) |
| Pricing | Finds `/pricing`, `/plans` links; extracts `$ € £ ₹` amounts with the nearest label; diffs against the previous snapshot |
| SEO | Candidate keywords from title + URL slug → **Keywords Everywhere** or **DataForSEO** → highest-volume candidate becomes the target keyword |
| Alerts | Slack webhook and/or SMTP email; sent only when there is something new or a price changed |

**Failure handling:** no blog → scan completes with "No blog detected"; 403/429/Cloudflare → one clear "Blocked" error, crawl stops after 3 blocks (optional Playwright fallback); timeouts retried once; invalid/expired SEO key or exhausted credits → one error, scan continues, articles stay `pending` and are re-enriched next scan; missing dates → NULL; private/internal IPs rejected (SSRF guard); per-scan errors shown on the dashboard.

## Run locally
```bash
git clone <your-repo-url> && cd competitor-monitor
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env        # fill in keys
python app.py               # http://localhost:5000
```
Optional browser fallback: `pip install playwright && playwright install chromium`, then `USE_PLAYWRIGHT=1`.

## Test
`python tests/test_flow.py` — starts real local HTTP servers (a blog with RSS + pagination + pricing, a no-blog site, a blocking site, a stub SEO API that rejects keys) and asserts: baseline finds all posts, **a 2nd scan reports 0 new**, a new post + price change is reported exactly once, and each failure mode degrades gracefully.

## Deploy
**Render (Docker):** push to GitHub → New → Blueprint → select repo (`render.yaml`) → set env vars. A persistent disk is needed or SQLite resets on redeploy (free tiers have none; alternatives: Fly.io/Railway volume, or swap `core.conn()` to Postgres). Run **one worker** (the Dockerfile does) because scans run in background threads.
**Set `DASHBOARD_PASSWORD`** — otherwise anyone with the URL can trigger scans.

## GitHub
```bash
git init && git add . && git commit -m "Competitor monitor"
git branch -M main && git remote add origin https://github.com/<you>/competitor-monitor.git && git push -u origin main
```
`.env` and `data/` are git-ignored; keys exist only as server environment variables.

## Known limitations
Price extraction is heuristic (labels may be imperfect; JS-rendered or "contact sales" pages need `USE_PLAYWRIGHT=1` or yield no prices). Keyword suggestion is rule-based on title/slug, not true SERP analysis. Heavily protected sites (Cloudflare challenge) may still block a plain HTTP client.
