"""Flask dashboard + JSON API. API keys live only in server-side environment variables."""
import json, logging, os, threading, time
from dotenv import load_dotenv
load_dotenv()
from flask import Flask, Response, flash, get_flashed_messages, jsonify, redirect, render_template, request
import core

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(message)s")
app = Flask(__name__); app.secret_key = os.getenv("SECRET_KEY", "change-me")
core.init_db()
RUNNING, LOCK = set(), threading.Lock()

def start_scan(cid):
    with LOCK:
        if cid in RUNNING: return False
        RUNNING.add(cid)
    def job():
        try: core.run_scan(cid)
        finally:
            with LOCK: RUNNING.discard(cid)
    threading.Thread(target=job, daemon=True).start(); return True

if os.getenv("SCAN_INTERVAL_HOURS"):   # optional scheduled scans
    def loop():
        while True:
            time.sleep(float(os.environ["SCAN_INTERVAL_HOURS"]) * 3600)
            for c in core.q("SELECT id FROM competitors"): start_scan(c["id"])
    threading.Thread(target=loop, daemon=True).start()

@app.before_request
def auth():
    pw = os.getenv("DASHBOARD_PASSWORD")
    if not pw or request.path == "/healthz": return
    a = request.authorization
    if not a or a.password != pw:
        return Response("Authentication required", 401, {"WWW-Authenticate": 'Basic realm="Competitor Monitor"'})

@app.get("/healthz")
def healthz(): return "ok"

@app.get("/")
def index():
    comps = core.q("SELECT c.*, (SELECT COUNT(*) FROM articles a WHERE a.competitor_id=c.id) n_articles FROM competitors c ORDER BY domain")
    for c in comps:
        if c["id"] in RUNNING: c["last_status"] = "running"
    sel = next((c for c in comps if str(c["id"]) == request.args.get("c", "")), comps[0] if comps else None)
    ctx = dict(comps=comps, sel=sel, tab=request.args.get("tab", "articles"), running=bool(RUNNING),
               cfg=dict(seo=os.getenv("SEO_PROVIDER") or "not configured",
                        alert=", ".join(x for x, v in (("Slack", os.getenv("SLACK_WEBHOOK_URL")), ("Email", os.getenv("SMTP_HOST"))) if v) or "not configured",
                        browser=os.getenv("USE_PLAYWRIGHT") == "1"))
    if sel:
        i = sel["id"]
        ctx.update(
            articles=core.q("SELECT * FROM articles WHERE competitor_id=? ORDER BY published_at IS NULL, published_at DESC, id DESC LIMIT 500", (i,)),
            scans=core.q("SELECT * FROM scans WHERE competitor_id=? ORDER BY id DESC LIMIT 25", (i,)),
            errors=core.q("SELECT * FROM errors WHERE competitor_id=? ORDER BY id DESC LIMIT 50", (i,)),
            changes=[dict(r, added=json.loads(r["added"]), removed=json.loads(r["removed"])) for r in
                     core.q("SELECT * FROM price_changes WHERE competitor_id=? ORDER BY id DESC LIMIT 30", (i,))],
            prices=[dict(r, prices=json.loads(r["prices"])) for r in core.q(
                "SELECT * FROM price_snapshots WHERE id IN (SELECT MAX(id) FROM price_snapshots WHERE competitor_id=? GROUP BY url)", (i,))],
            stats=core.q("SELECT COUNT(*) total, SUM(volume IS NOT NULL) with_seo, SUM(scan_id=?) new_last FROM articles WHERE competitor_id=?",
                         (sel["last_scan_id"], i))[0])
    return render_template("index.html", **ctx)

@app.post("/competitors")
def add():
    try: cid = core.add_competitor(request.form.get("domain"))
    except ValueError as e: flash(str(e)); return redirect("/")
    start_scan(cid); flash("Added — first scan started (this builds the baseline)."); return redirect(f"/?c={cid}")

@app.post("/competitors/<int:cid>/scan")
def scan(cid):
    if not core.q("SELECT 1 FROM competitors WHERE id=?", (cid,)): return "Not found", 404
    if not start_scan(cid): flash("A scan is already running for this competitor.")
    return redirect(f"/?c={cid}")

@app.post("/competitors/<int:cid>/delete")
def delete(cid):
    for t in ("articles", "scans", "errors", "price_snapshots", "price_changes"): core.ex(f"DELETE FROM {t} WHERE competitor_id=?", (cid,))
    core.ex("DELETE FROM competitors WHERE id=?", (cid,)); return redirect("/")

@app.get("/api/competitors/<int:cid>/articles")
def api_articles(cid): return jsonify(core.q("SELECT * FROM articles WHERE competitor_id=? ORDER BY id DESC", (cid,)))

@app.get("/api/competitors/<int:cid>/scans")
def api_scans(cid): return jsonify(core.q("SELECT * FROM scans WHERE competitor_id=? ORDER BY id DESC", (cid,)))

if __name__ == "__main__": app.run(port=int(os.getenv("PORT", "5000")), debug=False)
